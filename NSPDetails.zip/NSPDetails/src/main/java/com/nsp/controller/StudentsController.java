package com.nsp.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.java.pojo.Students;
import com.nsp.dao.StudentDao;


@Controller
public class StudentsController {
	@Autowired
	StudentDao dao;
	
	   @RequestMapping("/stuform")  
	    public String showform(Model m){  
	    	m.addAttribute("command", new Students());
	    	return "stuform"; 
	    }  
	   @RequestMapping(value="/save",method = RequestMethod.POST)  
	    public String save(@ModelAttribute("stu") Students stu){  
	        dao.save(stu);  
	        return "redirect:/";//will redirect to viewemp request mapping  
	    }  
	    /* It provides list of employees in model object */  
	    @RequestMapping("/viewstu")  
	    public String viewstu(Model m){  
	        List<Students> list=dao.getStudents();  
	        m.addAttribute("list",list);
	        return "viewstu";  
	    }  
	    /* It displays object data into form for the given id.  
	     * The @PathVariable puts URL data into variable.*/  
	    @RequestMapping(value="/editstu/{id}")  
	    public String edit(@PathVariable int id, Model m){  
	        Students stu =dao.getRollNumberById(id);
	        
	        m.addAttribute("command",stu);
	        return "editstu";  
	    }  
	    /* It updates model object. */  
	    @RequestMapping(value="/editsave",method = RequestMethod.POST)  
	    public String editsave(@ModelAttribute("stu") Students stu){  
	        dao.update(stu);  
	        return "redirect:/viewstu";  
	    }  
	    /* It deletes record for the given id in URL and redirects to /viewemp */  
	    @RequestMapping(value="/deletestu/{id}",method = RequestMethod.GET)  
	    public String delete(@PathVariable int id){  
	        dao.delete(id);  
	        return "redirect:/viewstu";  
	    }   
}
