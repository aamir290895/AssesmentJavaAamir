package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.layer2.Department;
import com.example.layer3.DepartmentRepository;

@SpringBootTest
class SpringOrmApplicationTests {
 @Autowired
 DepartmentRepository deptRepo;
	@Test
	void contextLoads() {
	}
	
	@Test
	void insertDepartment () {
		Department dept = new Department();
		dept.setDepartmentLocation("Pune");
		dept.setDepartmentName("QA");
		dept.setDepartmentNumber(786);
		
		deptRepo.insertDepartment(dept);
		
	}

}
