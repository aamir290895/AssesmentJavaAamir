module AssesmentJava {
}